﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ClassLibrary1
{
    public class CalculateSquareAndCube
    {
        public int SquareNumber(int number)
        {
            return number * number;
        }
        public int CubeNumber(int num)
        {
            return num * num * num;
        }
    }
}