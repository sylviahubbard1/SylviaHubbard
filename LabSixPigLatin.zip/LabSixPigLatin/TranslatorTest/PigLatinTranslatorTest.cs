﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LabSixPigLatin;

namespace TranslatorTest
{
    [TestClass]
    public class PigLatinTranslatorTest
    {
        [TestMethod]
        public void TestThatAppleTranslatesToAppleway()
        {
            string toTranslate = "apple";
            Translator brad = new Translator();

            string translatedString = brad.Translate(toTranslate);
            Assert.AreEqual("appleway", translatedString);


        }
        [TestMethod]
        public void TestThatBreadTranslatesToreadbway()
        {
            string toTranslate = "bread";
            Translator brad = new Translator();

            string translatedString = brad.Translate(toTranslate);
            Assert.AreEqual("eadbray", translatedString);


        }
        [TestMethod]
        public void TestThatLaptopTranslatesToAptoplway()
        {
            string toTranslate = "laptop";
            Translator brad = new Translator();

            string translatedString = brad.Translate(toTranslate);
            Assert.AreEqual("aptoplay", translatedString);


        }
        [TestMethod]
        public void TestThatScrapTranslatesToCrapsway()
        {
            string toTranslate = "scrap";
            Translator brad = new Translator();

            string translatedString = brad.Translate(toTranslate);
            Assert.AreEqual("apscray", translatedString);


        }
    }
}
