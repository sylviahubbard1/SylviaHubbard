﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabSixPigLatin
{
    public class Translator
    {
        public string Translate(string sentenceToTranslate)
        {
            string[] words = sentenceToTranslate.Split(' ');
            string translatedSentence = string.Empty;
            foreach (string oneWord in words)
            {
                translatedSentence += TranslateWord(oneWord)+ " ";
            }
            return translatedSentence.Trim(); 
        }

        private string TranslateWord(string wordToTranslate)
        {
            string firstcharacter = wordToTranslate.Substring(0, 1);
            if (firstcharacter == "a" || firstcharacter == "e" ||
                firstcharacter == "i" || firstcharacter == "u" ||
                firstcharacter == "o" || firstcharacter == "y")
            {
                return wordToTranslate + "way";
            }
            char[] letters = wordToTranslate.ToCharArray();
            for (int i = 0; i < letters.Length; i++)
            {
                char letter = letters[i];
                if (letter == 'a' || letter == 'e' ||
                    letter == 'i' || letter == 'u' ||
                    letter == 'o' || letter == 'y')
                {
                    string endingLetters = new String(letters, i, letters.Length - i);
                    string beginningLetters = new String(letters, 0, i);
                    return endingLetters + beginningLetters + "ay";
                }
            }
            return wordToTranslate;
        }

    }
} 