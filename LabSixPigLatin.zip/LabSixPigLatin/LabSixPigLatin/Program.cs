﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabSixPigLatin
{
    class Program
    {
        static void Main(string[] args)
        {
            Translator trans = new Translator();
            String yes;

            Console.WriteLine("Welcome to the Pig Latin Translator!\n Have Fun!");
            do
            {
                Console.Write("Enter a line to be translated: ");
                String sentence = Console.ReadLine();

                Console.WriteLine();
                String translatedSentence = trans.Translate(sentence);
                Console.WriteLine(translatedSentence);

                Console.WriteLine();

                Console.Write("Translate another line? y/n: ");
                yes = Console.ReadLine();

            } while (yes == "y");
            Console.WriteLine();
            Console.WriteLine("Thank you for translating. Goodbye!");

            Console.ReadLine();



        }
    }
}

